package v0;

public class Hammer extends Item{
	public Hammer(Player p){
		super("Hammer",p);
	}
}
