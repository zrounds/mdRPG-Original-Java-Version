package v0;

public class Paperweight extends Item {
	public Paperweight(Player p){
		super("Paperweight",p);
	}
}
