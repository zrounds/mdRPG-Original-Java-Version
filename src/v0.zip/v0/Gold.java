package v0;

public class Gold extends Item {
	public Gold(Player p){
		super("Gold", p);
	}
}
