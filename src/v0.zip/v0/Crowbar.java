package v0;

public class Crowbar extends Item{
	public Crowbar(Player player){
		super("Crowbar", player);
	}
}
