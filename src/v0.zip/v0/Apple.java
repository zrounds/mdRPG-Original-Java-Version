package v0;

public class Apple extends Item{
	public Apple(Player p){
		super ("Apple",p);
	}
}
